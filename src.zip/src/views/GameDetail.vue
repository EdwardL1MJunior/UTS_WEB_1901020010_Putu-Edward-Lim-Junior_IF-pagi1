<template>
  <div class="game-detail">
    <Navbar />
    <div class="container">

    <!-- breadcrumb -->
      <div class="row mt-5">
        <div class="col">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                  <router-link to="/" class="text-dark">Home</router-link>
              </li>
              <li class="breadcrumb-item">
                  <router-link to="/games" class="text-dark">Games</router-link>
              </li>
              <li class="breadcrumb-item active" aria-current="page">Game Order</li>
            </ol>
          </nav>
        </div>
      </div>

      <div class="row mt-2">
          <div class="col-md-6">
              <img :src=" '../assets/images/' + product.gambar " class="img-fluid shadow" /> 
          </div>
          <div class="col-md-6">
              <h2><strong>{{ product.nama }}</strong></h2>
              <hr>
              <h4>Harga : <strong>Rp. {{ product.harga }}</strong></h4>
              <form>
                  <div class="form-group">
                      <label for="jumlah_pemesanan">Jumlah Pesan</label>
                      <input type="number" class="form-control" />
                  </div>
                  <div class="form-group">
                      <label for="description">Description</label>
                      <textarea class="form-control" placeholder="Description is : RPG, Turn Base .."></textarea>
                  </div>

                  <button type="submit" class="btn btn-success"><b-icon-cart></b-icon-cart> Order</button>
              </form>
          </div>
      </div>


    </div>
  </div>
</template>

<script>
import Navbar from "@/components/Navbar.vue";
import axios from 'axios';

export default {
  name: "GameDetail",
  components: {
    Navbar,
  },
    data() {
        return {
            product: []
        }
  },
  methods: {
      setProducts(data) {
          this.product = data
      }
  },
 
 mounted() {
      axios
      .get("http://localhost:3000/products/"+this.$route.params.id)
      .then((response) => this.setProducts(response.data))
      .catch((error) => console.log(error));
  }
};
</script>

<style>
</style>